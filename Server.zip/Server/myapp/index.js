const express = require('express');
const admin = require('firebase-admin');

const serviceAccount = require('./service-account.json');
const { getDatabase } = require('firebase-admin/database');

admin.initializeApp({
  credential: admin.cert(serviceAccount),
  databaseURL: 'https://proyecto-web-fd280-default-rtdb.firebaseio.com'
});

const db = getDatabase();
const app = express();

app.get('/ping', (req, res) => res.send('pong'));

app.get('/', async (req, res) => {
  try {
    const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error('DB request timed out')), 8000));
    const snapshot = await Promise.race([db.ref('users').get(), timeout]);
    if (!snapshot.exists()) return res.send('No users found');
    return res.json(snapshot.val());
  } catch (err) {
    console.error('DB error:', err && err.message);
    res.status(500).send('DB error: ' + (err && err.message));
  }
});

app.listen(3000, () => {
  console.log('Server running on http://localhost:3000');
});